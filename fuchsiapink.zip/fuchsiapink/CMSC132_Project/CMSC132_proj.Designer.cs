﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.input = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.codeWindow = new System.Windows.Forms.DataGridView();
            this.instruction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.op1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.op1bincode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.op2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.op2bincode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.IF = new System.Windows.Forms.FlowLayoutPanel();
            this.cycleWindow = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.FlowLayoutPanel();
            this.ALU = new System.Windows.Forms.FlowLayoutPanel();
            this.EX = new System.Windows.Forms.FlowLayoutPanel();
            this.IF_LABEL = new System.Windows.Forms.Label();
            this.ID_LABEL = new System.Windows.Forms.Label();
            this.EX_LABEL = new System.Windows.Forms.Label();
            this.ALU_LABEL = new System.Windows.Forms.Label();
            this.previous = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.dataWindow = new System.Windows.Forms.DataGridView();
            this.operandcolumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.operandtypecolumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.currentvaluecolumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.registerWindow = new System.Windows.Forms.DataGridView();
            this.registercolumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valueregistercolumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.Column36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.codeWindow)).BeginInit();
            this.IF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cycleWindow)).BeginInit();
            this.ID.SuspendLayout();
            this.ALU.SuspendLayout();
            this.EX.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataWindow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registerWindow)).BeginInit();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // input
            // 
            this.input.Cursor = System.Windows.Forms.Cursors.Default;
            this.input.Location = new System.Drawing.Point(12, 33);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(265, 527);
            this.input.TabIndex = 0;
            this.input.Text = "";
            this.input.TextChanged += new System.EventHandler(this.input_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter code here:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(202, 568);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "ANALYZE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(294, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "CODE WINDOW";
            // 
            // codeWindow
            // 
            this.codeWindow.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.codeWindow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.codeWindow.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.instruction,
            this.opcode,
            this.op1,
            this.op1bincode,
            this.op2,
            this.op2bincode});
            this.codeWindow.Location = new System.Drawing.Point(297, 33);
            this.codeWindow.Name = "codeWindow";
            this.codeWindow.Size = new System.Drawing.Size(644, 157);
            this.codeWindow.TabIndex = 4;
            this.codeWindow.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.codeWindow_CellContentClick);
            // 
            // instruction
            // 
            this.instruction.HeaderText = "Instruction";
            this.instruction.Name = "instruction";
            // 
            // opcode
            // 
            this.opcode.HeaderText = "Instruction Binary Code";
            this.opcode.Name = "opcode";
            // 
            // op1
            // 
            this.op1.HeaderText = "Operand 1";
            this.op1.Name = "op1";
            // 
            // op1bincode
            // 
            this.op1bincode.HeaderText = "Operand 1 Binary Code";
            this.op1bincode.Name = "op1bincode";
            // 
            // op2
            // 
            this.op2.HeaderText = "Operand 2";
            this.op2.Name = "op2";
            // 
            // op2bincode
            // 
            this.op2bincode.HeaderText = "Operand 2 Binary Code";
            this.op2bincode.Name = "op2bincode";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(294, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "CYCLE WINDOW";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(305, 391);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "PIPELINE WINDOW";
            // 
            // IF
            // 
            this.IF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.IF.Controls.Add(this.IF_LABEL);
            this.IF.Location = new System.Drawing.Point(365, 454);
            this.IF.Name = "IF";
            this.IF.Size = new System.Drawing.Size(74, 68);
            this.IF.TabIndex = 8;
            this.IF.Paint += new System.Windows.Forms.PaintEventHandler(this.pipelineWindow_Paint);
            // 
            // cycleWindow
            // 
            this.cycleWindow.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.cycleWindow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cycleWindow.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column22,
            this.Column23,
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column30,
            this.Column31,
            this.Column32,
            this.Column33,
            this.Column34,
            this.Column35,
            this.Column36,
            this.Column37,
            this.Column38,
            this.Column39,
            this.Column40,
            this.Column41,
            this.Column42,
            this.Column43,
            this.Column44,
            this.Column45,
            this.Column46,
            this.Column47,
            this.Column48,
            this.Column49,
            this.Column50});
            this.cycleWindow.Location = new System.Drawing.Point(297, 214);
            this.cycleWindow.Name = "cycleWindow";
            this.cycleWindow.Size = new System.Drawing.Size(644, 164);
            this.cycleWindow.TabIndex = 5;
            this.cycleWindow.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.cycleWindow_CellContentClick);
            // 
            // ID
            // 
            this.ID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ID.Controls.Add(this.ID_LABEL);
            this.ID.Location = new System.Drawing.Point(492, 454);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(74, 68);
            this.ID.TabIndex = 9;
            // 
            // ALU
            // 
            this.ALU.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ALU.Controls.Add(this.ALU_LABEL);
            this.ALU.Location = new System.Drawing.Point(648, 492);
            this.ALU.Name = "ALU";
            this.ALU.Size = new System.Drawing.Size(74, 68);
            this.ALU.TabIndex = 10;
            this.ALU.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel2_Paint);
            // 
            // EX
            // 
            this.EX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.EX.Controls.Add(this.EX_LABEL);
            this.EX.Location = new System.Drawing.Point(648, 395);
            this.EX.Name = "EX";
            this.EX.Size = new System.Drawing.Size(74, 68);
            this.EX.TabIndex = 9;
            // 
            // IF_LABEL
            // 
            this.IF_LABEL.AutoSize = true;
            this.IF_LABEL.Location = new System.Drawing.Point(3, 0);
            this.IF_LABEL.Name = "IF_LABEL";
            this.IF_LABEL.Size = new System.Drawing.Size(0, 13);
            this.IF_LABEL.TabIndex = 11;
            // 
            // ID_LABEL
            // 
            this.ID_LABEL.AutoSize = true;
            this.ID_LABEL.Location = new System.Drawing.Point(3, 0);
            this.ID_LABEL.Name = "ID_LABEL";
            this.ID_LABEL.Size = new System.Drawing.Size(0, 13);
            this.ID_LABEL.TabIndex = 12;
            // 
            // EX_LABEL
            // 
            this.EX_LABEL.AutoSize = true;
            this.EX_LABEL.Location = new System.Drawing.Point(3, 0);
            this.EX_LABEL.Name = "EX_LABEL";
            this.EX_LABEL.Size = new System.Drawing.Size(0, 13);
            this.EX_LABEL.TabIndex = 13;
            // 
            // ALU_LABEL
            // 
            this.ALU_LABEL.AutoSize = true;
            this.ALU_LABEL.Location = new System.Drawing.Point(3, 0);
            this.ALU_LABEL.Name = "ALU_LABEL";
            this.ALU_LABEL.Size = new System.Drawing.Size(0, 13);
            this.ALU_LABEL.TabIndex = 14;
            // 
            // previous
            // 
            this.previous.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.previous.Location = new System.Drawing.Point(785, 456);
            this.previous.Name = "previous";
            this.previous.Size = new System.Drawing.Size(88, 23);
            this.previous.TabIndex = 15;
            this.previous.Text = "PREVIOUS";
            this.previous.UseVisualStyleBackColor = true;
            this.previous.Click += new System.EventHandler(this.previous_Click);
            // 
            // next
            // 
            this.next.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.Location = new System.Drawing.Point(785, 492);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(88, 23);
            this.next.TabIndex = 16;
            this.next.Text = "NEXT";
            this.next.UseVisualStyleBackColor = true;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // dataWindow
            // 
            this.dataWindow.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataWindow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataWindow.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.operandcolumn,
            this.operandtypecolumn,
            this.currentvaluecolumn});
            this.dataWindow.Location = new System.Drawing.Point(972, 33);
            this.dataWindow.Name = "dataWindow";
            this.dataWindow.Size = new System.Drawing.Size(240, 265);
            this.dataWindow.TabIndex = 17;
            this.dataWindow.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataWindow_CellContentClick);
            // 
            // operandcolumn
            // 
            this.operandcolumn.HeaderText = "Operand";
            this.operandcolumn.Name = "operandcolumn";
            // 
            // operandtypecolumn
            // 
            this.operandtypecolumn.HeaderText = "Type";
            this.operandtypecolumn.Name = "operandtypecolumn";
            // 
            // currentvaluecolumn
            // 
            this.currentvaluecolumn.HeaderText = "Current Value";
            this.currentvaluecolumn.Name = "currentvaluecolumn";
            // 
            // registerWindow
            // 
            this.registerWindow.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.registerWindow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.registerWindow.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.registercolumn,
            this.valueregistercolumn});
            this.registerWindow.Location = new System.Drawing.Point(972, 327);
            this.registerWindow.Name = "registerWindow";
            this.registerWindow.Size = new System.Drawing.Size(240, 264);
            this.registerWindow.TabIndex = 19;
            // 
            // registercolumn
            // 
            this.registercolumn.HeaderText = "Register";
            this.registercolumn.Name = "registercolumn";
            // 
            // valueregistercolumn
            // 
            this.valueregistercolumn.HeaderText = "Current Value";
            this.valueregistercolumn.Name = "valueregistercolumn";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(969, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "DATA  WINDOW";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(969, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "REGISTER WINDOW";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(391, 525);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "IF";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(521, 525);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(377, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "EX";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(370, 177);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "ALU";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(439, 483);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(53, 10);
            this.panel1.TabIndex = 14;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(597, 424);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(29, 10);
            this.panel2.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel3.Location = new System.Drawing.Point(565, 467);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(35, 10);
            this.panel3.TabIndex = 16;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel4.Location = new System.Drawing.Point(565, 496);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(35, 10);
            this.panel4.TabIndex = 17;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel5.Location = new System.Drawing.Point(597, 525);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(29, 10);
            this.panel5.TabIndex = 26;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel6.Location = new System.Drawing.Point(597, 433);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 44);
            this.panel6.TabIndex = 27;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel7.Location = new System.Drawing.Point(597, 496);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 39);
            this.panel7.TabIndex = 28;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Instruction";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Cycle 1";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Cycle 2";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Cycle 3";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Cycle 4";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Cycle 5";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Cycle 6";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Cycle 7";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Cycle 8";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Cycle 9";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Cycle 10";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Cycle 11";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Cycle 12";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Cycle 13";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Cycle 14";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Cycle 15";
            this.Column15.Name = "Column15";
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Cycle 16";
            this.Column16.Name = "Column16";
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Cycle 17";
            this.Column17.Name = "Column17";
            // 
            // Column18
            // 
            this.Column18.HeaderText = "Cycle 18";
            this.Column18.Name = "Column18";
            // 
            // Column19
            // 
            this.Column19.HeaderText = "Cycle 19";
            this.Column19.Name = "Column19";
            // 
            // Column20
            // 
            this.Column20.HeaderText = "Cycle 20";
            this.Column20.Name = "Column20";
            // 
            // Column21
            // 
            this.Column21.HeaderText = "Cycle 21";
            this.Column21.Name = "Column21";
            // 
            // Column22
            // 
            this.Column22.HeaderText = "Cycle 22";
            this.Column22.Name = "Column22";
            // 
            // Column23
            // 
            this.Column23.HeaderText = "Cycle 23";
            this.Column23.Name = "Column23";
            // 
            // Column24
            // 
            this.Column24.HeaderText = "Cycle 24";
            this.Column24.Name = "Column24";
            // 
            // Column25
            // 
            this.Column25.HeaderText = "Cycle 25";
            this.Column25.Name = "Column25";
            // 
            // Column26
            // 
            this.Column26.HeaderText = "Cycle 26";
            this.Column26.Name = "Column26";
            // 
            // Column27
            // 
            this.Column27.HeaderText = "Cycle 27";
            this.Column27.Name = "Column27";
            // 
            // Column28
            // 
            this.Column28.HeaderText = "Cycle 28";
            this.Column28.Name = "Column28";
            // 
            // Column29
            // 
            this.Column29.HeaderText = "Cycle 29";
            this.Column29.Name = "Column29";
            // 
            // Column30
            // 
            this.Column30.HeaderText = "Cycle 30";
            this.Column30.Name = "Column30";
            // 
            // Column31
            // 
            this.Column31.HeaderText = "Cycle 31";
            this.Column31.Name = "Column31";
            // 
            // Column32
            // 
            this.Column32.HeaderText = "Cycle 32";
            this.Column32.Name = "Column32";
            // 
            // Column33
            // 
            this.Column33.HeaderText = "Cycle 33";
            this.Column33.Name = "Column33";
            // 
            // Column34
            // 
            this.Column34.HeaderText = "Cycle 34";
            this.Column34.Name = "Column34";
            // 
            // Column35
            // 
            this.Column35.HeaderText = "Cycle 35";
            this.Column35.Name = "Column35";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel8.Location = new System.Drawing.Point(597, 424);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(53, 10);
            this.panel8.TabIndex = 15;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel9.Location = new System.Drawing.Point(597, 525);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(53, 10);
            this.panel9.TabIndex = 15;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel11.Controls.Add(this.label10);
            this.panel11.Controls.Add(this.label9);
            this.panel11.Location = new System.Drawing.Point(297, 384);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(644, 207);
            this.panel11.TabIndex = 0;
            // 
            // Column36
            // 
            this.Column36.HeaderText = "Cycle 36";
            this.Column36.Name = "Column36";
            // 
            // Column37
            // 
            this.Column37.HeaderText = "Cycle 37";
            this.Column37.Name = "Column37";
            // 
            // Column38
            // 
            this.Column38.HeaderText = "Cycle 38";
            this.Column38.Name = "Column38";
            // 
            // Column39
            // 
            this.Column39.HeaderText = "Cycle 39";
            this.Column39.Name = "Column39";
            // 
            // Column40
            // 
            this.Column40.HeaderText = "Cycle 40";
            this.Column40.Name = "Column40";
            // 
            // Column41
            // 
            this.Column41.HeaderText = "Cycle 41";
            this.Column41.Name = "Column41";
            // 
            // Column42
            // 
            this.Column42.HeaderText = "Cycle 42";
            this.Column42.Name = "Column42";
            // 
            // Column43
            // 
            this.Column43.HeaderText = "Cycle 43";
            this.Column43.Name = "Column43";
            // 
            // Column44
            // 
            this.Column44.HeaderText = "Cycle 44";
            this.Column44.Name = "Column44";
            // 
            // Column45
            // 
            this.Column45.HeaderText = "Cycle 45";
            this.Column45.Name = "Column45";
            // 
            // Column46
            // 
            this.Column46.HeaderText = "Cycle 46";
            this.Column46.Name = "Column46";
            // 
            // Column47
            // 
            this.Column47.HeaderText = "Cycle 47";
            this.Column47.Name = "Column47";
            // 
            // Column48
            // 
            this.Column48.HeaderText = "Cycle 48";
            this.Column48.Name = "Column48";
            // 
            // Column49
            // 
            this.Column49.HeaderText = "Cycle 49";
            this.Column49.Name = "Column49";
            // 
            // Column50
            // 
            this.Column50.HeaderText = "Cycle 50";
            this.Column50.Name = "Column50";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1226, 603);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.registerWindow);
            this.Controls.Add(this.dataWindow);
            this.Controls.Add(this.next);
            this.Controls.Add(this.previous);
            this.Controls.Add(this.ALU);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.cycleWindow);
            this.Controls.Add(this.IF);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.codeWindow);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.input);
            this.Controls.Add(this.EX);
            this.Controls.Add(this.panel11);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "CMSC 132 PROJECT";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.codeWindow)).EndInit();
            this.IF.ResumeLayout(false);
            this.IF.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cycleWindow)).EndInit();
            this.ID.ResumeLayout(false);
            this.ID.PerformLayout();
            this.ALU.ResumeLayout(false);
            this.ALU.PerformLayout();
            this.EX.ResumeLayout(false);
            this.EX.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataWindow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registerWindow)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox input;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView codeWindow;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.FlowLayoutPanel IF;
        private System.Windows.Forms.DataGridViewTextBoxColumn instruction;
        private System.Windows.Forms.DataGridViewTextBoxColumn opcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn op1;
        private System.Windows.Forms.DataGridViewTextBoxColumn op1bincode;
        private System.Windows.Forms.DataGridViewTextBoxColumn op2;
        private System.Windows.Forms.DataGridViewTextBoxColumn op2bincode;
        private System.Windows.Forms.DataGridView cycleWindow;
        private System.Windows.Forms.FlowLayoutPanel ID;
        private System.Windows.Forms.FlowLayoutPanel ALU;
        private System.Windows.Forms.FlowLayoutPanel EX;
        private System.Windows.Forms.Label IF_LABEL;
        private System.Windows.Forms.Label ID_LABEL;
        private System.Windows.Forms.Label EX_LABEL;
        private System.Windows.Forms.Label ALU_LABEL;
        private System.Windows.Forms.Button previous;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.DataGridView dataWindow;
        private System.Windows.Forms.DataGridView registerWindow;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn operandcolumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn operandtypecolumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn currentvaluecolumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn registercolumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueregistercolumn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column39;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column41;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column42;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column43;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column44;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column45;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column46;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column47;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column48;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column49;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column50;
    }
}

