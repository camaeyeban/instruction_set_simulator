Installation Guide

To run the program user must:
� Download and install a Microsoft Visual C# version 2010 Express or any latest version from https://www.visualstudio.com/en-us/products/
� Extract the zip file: fuchsiapink.zip
� Open in Microsoft Visual C# the file named CMSC132_proj.cs
� In the window of Microsoft Visual C# there is a green triangle button named Start Debugging button. Press that button or F5 in order to run the program
